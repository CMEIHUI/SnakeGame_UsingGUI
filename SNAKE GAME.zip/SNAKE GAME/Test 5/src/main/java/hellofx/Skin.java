package hellofx;

public enum Skin {
    CLASSIC,
    NEON,
    RETRO,
    DARK,
    LIGHT
}
