# SnakeFX Deluxe - Runnable JavaFX Project

## How to run

1. Install JDK 17 or 21.
2. Download JavaFX SDK from https://openjfx.io/ and extract.
3. In `.vscode/launch.json` set `--module-path` to the JavaFX SDK `lib` folder.
4. Open this project in VS Code with Java extensions and run the `Launch Main` configuration.

## Notes

- This project uses a simple `Audio.playSound` stub that prints to console.
- To enable actual audio, replace stub with `AudioClip` or `MediaPlayer`.
